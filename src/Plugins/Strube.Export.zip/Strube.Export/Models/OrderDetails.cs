﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Strube.Export.Models
{
    public class OrderDetails:List<OrderDetail>
    {
    }
}